import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function calendarSyncAndBotScheduleHandler() {
  try {
    await syncAllUserCalendars();

    await scheduleBotsForUpcomingMeetings();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "success" }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message,
      }),
    };
  } finally {
    await prisma.$disconnect();
  }
}

async function syncAllUserCalendars() {
  const users = await prisma.user.findMany({
    where: {
      calendarConnected: true,
      accounts: {
        some: {
          accessToken: { not: null },
        },
      },
    },
    include: {
      accounts: {
        where: {
          accessToken: { not: null },
        },
      },
    },
  });

  for (const user of users) {
    try {
      await syncUserCalendar(user);
    } catch (error) {
      console.error(`Sync failed for ${user.id}:`, error.message);
    }
  }
}

async function syncUserCalendar(user) {
  try {
    let accessToken = user.accounts[0]?.accessToken;

    const now = new Date();
    const tokenExpiry = new Date(user.accounts[0]?.accessTokenExpiresAt);
    const tenMinutesFromNow = new Date(now.getTime() + 10 * 60 * 1000);

    if (tokenExpiry <= tenMinutesFromNow) {
      accessToken = await refreshGoogleToken(user);
      if (!accessToken) {
        return;
      }
    }
    const sevenDays = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    const response = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/primary/events?` +
        `timeMin=${now.toISOString()}&` +
        `timeMax=${sevenDays.toISOString()}&` +
        `singleEvents=true&orderBy=startTime&showDeleted=true`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );
    if (!response.ok) {
      if (response.status === 401) {
        await prisma.user.update({
          where: {
            id: user.id,
          },
          data: {
            calendarConnected: false,
          },
        });
        return;
      }
      throw new Error(`Calendar API failed to connect: ${response.status}`);
    }
    const data = await response.json();
    const events = data.items || [];
    const existingEvents = await prisma.meeting.findMany({
      where: {
        userId: user.id,
        isFromCalendar: true,
        startTime: {
          gte: now,
        },
      },
    });

    const googleEventIds = new Set();
    for (const event of events) {
      if (event.status === "cancelled") {
        await handleRemoveEvent(event);
        continue;
      }
      googleEventIds.add(event.id);
      await processEvent(user, event);
    }

    const deletedEvents = existingEvents.filter(
      (dbEvent) => !googleEventIds.has(dbEvent.calendarEventId)
    );

    if (deletedEvents.length > 0) {
      for (const deletedEvent of deletedEvents) {
        await handleRemoveEventFromDB(user, deletedEvent);
      }
    }
  } catch (error) {
    console.error(`Calendar error for ${user.id}:`, error.message);
    if (error.message.includes("401") || error.message.includes("403")) {
      await prisma.user.update({
        where: {
          id: user.id,
        },
        data: {
          calendarConnected: false,
        },
      });
    }
  }
}

async function refreshGoogleToken(user) {
  try {
    const refreshToken = user.accounts[0]?.refreshToken;
    if (!refreshToken) {
      await prisma.user.update({
        where: {
          id: user.id,
        },
        data: {
          calendarConnected: false,
          accounts: {
            updateMany: {
              where: {
                provider: "google",
              },
              data: {
                refreshToken: null,
              },
            },
          },
        },
      });
      return null;
    }

    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
      }),
    });
    const tokens = await response.json();

    if (!tokens.access_token) {
      await prisma.user.update({
        where: {
          id: user.id,
        },
        data: {
          calendarConnected: false,
        },
      });
      return null;
    }

    await prisma.user.update({
      where: {
        id: user.id,
      },
      data: {
        accounts: {
          updateMany: {
            where: {
              provider: "google",
            },
            data: {
              accessToken: tokens.access_token,
              accessTokenExpiresAt: new Date(
                Date.now() + tokens.expires_in * 1000
              ),
            },
          },
        },
      },
    });
    return tokens.access_token;
  } catch (error) {
    console.error(`Token refresh error for ${user.id}: `, error);
    await prisma.user.update({
      where: {
        id: user.id,
      },
      data: {
        calendarConnected: false,
      },
    });
    return null;
  }
}

async function handleRemoveEvent(event) {
  try {
    const exsistingMeeting = await prisma.meeting.findUnique({
      where: {
        calendarEventId: event.id,
      },
    });
    if (exsistingMeeting) {
      await prisma.meeting.delete({
        where: {
          calendarEventId: event.id,
        },
      });
    }
  } catch (error) {
    console.error("Error deleting event:", error.message);
  }
}

async function handleRemoveEventFromDB(dbEvent) {
  await prisma.meeting.delete({
    where: {
      id: dbEvent.id,
    },
  });
}

async function processEvent(user, event) {
  const meetingUrl =
    event.hangoutLink || event.conferenceData?.entryPoints?.[0]?.uri;
  if (!meetingUrl || !event.start?.dateTime) {
    return;
  }

  const eventData = {
    calendarEventId: event.id,
    userId: user.id,
    title: event.summary || "Untitled Meeting",
    description: event.description || null,
    meetingUrl: meetingUrl,
    startTime: new Date(event.start.dateTime),
    endTime: new Date(event.end.dateTime),
    attendees: event.attendees
      ? JSON.stringify(event.attendees.map((a) => a.email))
      : null,
    isFromCalendar: true,
    botScheduled: true,
  };

  try {
    const exsistingMeeting = await prisma.meeting.findUnique({
      where: {
        calendarEventId: event.id,
      },
    });

    if (exsistingMeeting) {
      const changes = [];
      if (exsistingMeeting.title !== eventData.title) changes.push("title");
      if (
        exsistingMeeting.startTime.getTime() !== eventData.startTime.getTime()
      )
        changes.push("time");
      if (exsistingMeeting.meetingUrl !== eventData.meetingUrl)
        changes.push("meeting url");
      if (exsistingMeeting.attendees !== eventData.attendees)
        changes.push("attendees");

      const updateData = {
        title: eventData.title,
        description: eventData.description,
        meetingUrl: eventData.meetingUrl,
        startTime: eventData.startTime,
        endTime: eventData.endTime,
        attendees: eventData.attendees,
      };

      if (!exsistingMeeting.botSent) {
        updateData.botScheduled = eventData.botScheduled;
      }
      await prisma.meeting.update({
        where: {
          calendarEventId: event.id,
        },
        data: updateData,
      });
    } else {
      await prisma.meeting.create({
        data: eventData,
      });
    }
  } catch (error) {
    console.error(`error for ${event.id}:`, error.message);
  }
}

async function scheduleBotsForUpcomingMeetings() {
  const now = new Date();
  const fiveMinutesFromNow = new Date(now.getTime() + 5 * 60 * 1000);

  const upcomingMeetings = await prisma.meeting.findMany({
    where: {
      startTime: {
        gte: now,
        lte: fiveMinutesFromNow,
      },
      botScheduled: true,
      botSent: false,
      meetingUrl: {
        not: null,
      },
    },
    include: {
      user: true,
    },
  });

  for (const meeting of upcomingMeetings) {
    try {
      const canSchedule = await canUserScheduleMeeting(meeting.user);

      if (!canSchedule.allowed) {
        await prisma.meeting.update({
          where: {
            id: meeting.id,
          },
          data: {
            botSent: true,
            botJoinedAt: new Date(),
          },
        });
        continue;
      }
      const requestBody = {
        meeting_url: meeting.meetingUrl,
        bot_name: meeting.user.botName || "Vorcle Notetaker",
        reserved: false,
        recording_mode: "speaker_view",
        speech_to_text: { provider: "Default" },
        webhook_url: process.env.WEBHOOK_URL,
        extra: {
          meeting_id: meeting.id,
          user_id: meeting.userId,
        },
      };

      if (meeting.user.botImageUrl) {
        requestBody.bot_image = meeting.user.botImageUrl;
      }

      const response = await fetch("https://api.meetingbaas.com/bots", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-meeting-baas-api-key": process.env.MEETING_BAAS_API_KEY,
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error(`meeting baas api req failed: ${response.status}`);
      }

      const data = await response.json();

      await prisma.meeting.update({
        where: {
          id: meeting.id,
        },
        data: {
          botSent: true,
          botId: data.bot_id,
          botJoinedAt: new Date(),
        },
      });

      await incrementMeetingUsage(meeting.userId);
    } catch (error) {
      console.error(`bot failed for ${meeting.title}: `, error.message);
    }
  }
}

async function canUserScheduleMeeting(user) {
  try {
    const PLAN_LIMITS = {
      FREE: { meetings: 0 },
      PRO: { meetings: 10 },
      BUSINESS: { meetings: 30 },
      ENTERPRISE: { meetings: -1 },
    };
    const limits = PLAN_LIMITS[user.currentPlan] || PLAN_LIMITS.FREE;

    if (user.currentPlan === "FREE" || user.subscriptionStatus !== "ACTIVE") {
      return {
        allowed: false,
        reason: `${
          user.currentPlan === "FREE" ? "Free plan" : "Inactive subscription"
        } - upgrade required`,
      };
    }

    if (limits.meetings !== -1 && user.meetingsThisMonth >= limits.meetings) {
      return {
        allowed: false,
        reason: `Monthly limit reached (${user.meetingsThisMonth}/${limits.meetings})`,
      };
    }
    return {
      allowed: true,
    };
  } catch (error) {
    console.error("Error checking meeting limits:", error);
    return {
      allowed: false,
      reason: "Error checking limits ",
    };
  }
}

async function incrementMeetingUsage(userId) {
  try {
    await prisma.user.update({
      where: {
        id: userId,
      },
      data: {
        meetingsThisMonth: {
          increment: 1,
        },
      },
    });
  } catch (error) {
    console.error("Error incrementing meeting usage:", error);
  }
}
